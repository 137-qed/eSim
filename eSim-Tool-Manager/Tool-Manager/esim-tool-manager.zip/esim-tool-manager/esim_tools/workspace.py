"""User-owned configuration, action journal, and manager-level locking."""

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from collections import deque
import json
import os
from pathlib import Path
import tempfile

from .apt import ManagerError


def default_path(variable, fallback, filename):
    base = Path(os.environ.get(variable, ""))
    if not base.is_absolute():
        base = Path.home() / fallback
    return base / "esim-tool-manager" / filename


@dataclass(frozen=True)
class Settings:
    launcher: str = "esim"
    bin_dirs: tuple[str, ...] = ()

    @classmethod
    def read(cls, path):
        try:
            document = json.loads(path.read_text())
        except FileNotFoundError:
            return cls()
        except (ValueError, OSError) as error:
            raise ManagerError(f"Cannot read profile {path}: {error}") from error
        if not isinstance(document, dict) or document.keys() - {"launcher", "bin_dirs"}:
            raise ManagerError(f"Profile {path} expects launcher and bin_dirs fields.")
        launcher = document.get("launcher", "esim")
        paths = document.get("bin_dirs", [])
        if not isinstance(paths, list):
            raise ManagerError(f"Profile {path} expects bin_dirs to be a list.")
        return cls.validate(launcher, paths)

    @classmethod
    def validate(cls, launcher, paths):
        if not isinstance(launcher, str) or (
            launcher != "esim" and not Path(launcher).is_absolute()
        ) or "\0" in launcher:
            raise ManagerError("The eSim launcher must be 'esim' or an absolute executable path.")
        for path in paths:
            if not isinstance(path, str) or not Path(path).is_absolute() or ":" in path or "\0" in path:
                raise ManagerError("Each tool directory must be an absolute path without a colon.")
        return cls(launcher, tuple(dict.fromkeys(paths)))

    def write(self, path):
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=path.parent, mode="w", delete=False) as output:
            temporary = Path(output.name)
            try:
                json.dump({"launcher": self.launcher, "bin_dirs": self.bin_dirs}, output, indent=2)
                output.write("\n")
                output.close()
                temporary.replace(path)
            finally:
                temporary.unlink(missing_ok=True)

    def environment(self):
        paths = (*self.bin_dirs, os.environ.get("PATH") or os.defpath)
        return dict(os.environ, PATH=os.pathsep.join(paths))


class Journal:
    def __init__(self, path):
        self.path = path

    def append(self, action, result, **fields):
        self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        event = dict(time=datetime.now(timezone.utc).isoformat(), action=action, result=result, **fields)
        line = json.dumps(event, ensure_ascii=True) + "\n"
        with open(self.path, "a", opener=lambda path, flags: os.open(path, flags, 0o600)) as log:
            log.write(line)

    def tail(self, count):
        if not self.path.is_file():
            return []
        with self.path.open() as log:
            return [json.loads(line) for line in deque(log, maxlen=count)]

    @contextmanager
    def mutation_lock(self):
        import fcntl

        self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with (self.path.parent / "operation.lock").open("a") as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as error:
                raise ManagerError("Another tool manager operation is running for this profile.") from error
            yield
