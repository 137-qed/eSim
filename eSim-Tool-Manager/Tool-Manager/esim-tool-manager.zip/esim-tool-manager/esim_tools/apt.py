"""Translate manager operations into Ubuntu package-manager commands."""

from dataclasses import dataclass
import os
from pathlib import Path
import re
import shutil
import subprocess

from .catalog import Tool


class ManagerError(Exception):
    pass


APT = ("/usr/bin/apt-get", "--no-remove", "--no-install-recommends",
       "-o", "APT::Get::allow-downgrades=false",
       "-o", "APT::Get::allow-change-held-packages=false")
# A Debian version starts with a digit, optionally preceded by a numeric epoch.
VERSION = re.compile(r"(?:[0-9]+:)?[0-9][A-Za-z0-9.+~\-]*")
CHANGE = re.compile(r"^Inst (\S+)(?: \[([^\]]+)\])? \((\S+)")
STATUS_SEPARATOR = "\t"


@dataclass(frozen=True)
class Package:
    state: str
    installed: str | None
    candidate: str | None
    held: bool = False


@dataclass(frozen=True)
class Change:
    package: str
    before: str | None
    after: str


@dataclass(frozen=True)
class Plan:
    command: tuple[str, ...]
    targets: tuple[tuple[str, str], ...]
    changes: tuple[Change, ...]


def system_run(args, *, stream=False):
    env = os.environ.copy()
    for variable in ("APT_CONFIG", "DPKG_ROOT", "DPKG_ADMINDIR"):
        env.pop(variable, None)
    env.update(LC_ALL="C", PATH="/usr/sbin:/usr/bin:/sbin:/bin")
    return subprocess.run(args, env=env, text=True, capture_output=not stream)


def require_ubuntu():
    release = Path("/etc/os-release")
    if not release.is_file() or not re.search(
        r'^ID=(?:"ubuntu"|ubuntu)$', release.read_text(), re.MULTILINE
    ):
        raise ManagerError("The package manager requires Ubuntu with APT and dpkg.")
    for command in ("/usr/bin/apt-get", "/usr/bin/apt-cache", "/usr/bin/dpkg-query", "/usr/bin/dpkg"):
        if not os.access(command, os.X_OK):
            raise ManagerError(f"Required Ubuntu package command is missing: {command}")


class Apt:
    def __init__(self, run=system_run, effective_uid=None):
        self.run = run
        self.effective_uid = effective_uid or os.geteuid

    def checked(self, args, *, stream=False):
        result = self.run(args, stream=stream)
        if result.returncode:
            output = "\n".join(part.strip() for part in (result.stdout, result.stderr) if part)
            detail = f"\n{output}" if output else ""
            raise ManagerError(f"{Path(args[0]).name} exited with {result.returncode}.{detail}")
        return result.stdout or ""

    def elevated(self, args):
        if self.effective_uid() == 0:
            return args
        sudo = "/usr/bin/sudo"
        if not os.access(sudo, os.X_OK):
            raise ManagerError("Install sudo or run this operation from a root login.")
        return (sudo, *args)

    def inspect(self, tool: Tool):
        query = self.run((
            "/usr/bin/dpkg-query", "-W",
            "-f=${db:Status-Want}\t${db:Status-Status}\t${Version}\n", tool.package,
        ))
        state, installed, held = "absent", None, False
        if query.returncode == 0:
            fields = query.stdout.rstrip("\n").split(STATUS_SEPARATOR)
            if len(fields) != 3:
                raise ManagerError(f"Unexpected dpkg record for {tool.package}.")
            wanted, status, version = fields
            held = wanted == "hold"
            if status == "installed":
                state, installed = "installed", version
            elif status not in {"not-installed", "config-files"}:
                state = status
        elif query.returncode != 1 or "no packages found matching" not in query.stderr:
            raise ManagerError(f"dpkg-query failed for {tool.package}.\n{query.stderr.strip()}")
        policy = self.checked(("/usr/bin/apt-cache", "policy", tool.package))
        candidate_match = re.search(r"^\s*Candidate:\s+(\S+)", policy, re.MULTILINE)
        candidate = candidate_match[1] if candidate_match else "(none)"
        return Package(state, installed, None if candidate == "(none)" else candidate, held)

    def newer(self, left, right):
        result = self.run(("/usr/bin/dpkg", "--compare-versions", left, "gt", right))
        if result.returncode not in (0, 1):
            raise ManagerError(f"Could not compare Debian versions {left!r} and {right!r}.")
        return result.returncode == 0

    def refresh(self):
        self.checked(self.elevated(("/usr/bin/apt-get", "-o", "APT::Update::Error-Mode=any",
                                    "update")), stream=True)

    def simulate(self, command, targets):
        output = self.checked((command[0], "--simulate", *command[1:]))
        changes = []
        configured = set()
        for line in output.splitlines():
            if line.startswith(("Remv ", "Purg ", "The following packages will be DOWNGRADED:")):
                raise ManagerError("APT would remove or downgrade packages. Choose another version.")
            if line.startswith("Conf "):
                configured.add(line.split()[1])
            if line.startswith("Inst "):
                match = CHANGE.match(line)
                if not match:
                    raise ManagerError(f"Unrecognized APT transaction output: {line}")
                changes.append(Change(*match.groups()))
        if configured - {change.package for change in changes}:
            raise ManagerError("Unfinished package configuration is pending. Check with dpkg --audit.")
        scheduled = {(change.package.split(":", 1)[0], change.after) for change in changes}
        missing = set(targets) - scheduled
        if missing:
            raise ManagerError("APT did not schedule every selected package at the requested version.")
        return Plan(command, targets, tuple(changes))

    def plan(self, operation, tools, pins):
        targets = []
        for tool in tools:
            package = self.inspect(tool)
            if package.state not in {"absent", "installed"}:
                raise ManagerError(f"{tool.package} is {package.state}. Check with dpkg --audit.")
            if operation == "upgrade" and package.installed is None:
                raise ManagerError(f"{tool.name} is missing. Run install first.")
            pinned = pins.get(tool.name)
            target = pinned or package.candidate
            if target is None:
                if package.installed:
                    continue
                raise ManagerError(f"No APT candidate for {tool.package}. Check Ubuntu package sources "
                                   "and refresh the index.")
            if not VERSION.fullmatch(target):
                raise ManagerError(f"Unexpected Debian version for {tool.package}: {target!r}")
            if package.installed == target:
                continue
            if package.installed and self.newer(package.installed, target):
                if pinned:
                    raise ManagerError(f"{tool.name} downgrade refused: {package.installed} to {target}.")
                continue
            if package.held:
                raise ManagerError(f"{tool.package} is held by APT. Review the hold before proceeding.")
            targets.append((tool.package, target))

        only_upgrade = ("--only-upgrade",) if operation == "upgrade" else ()
        command = (*APT, *only_upgrade, "install",
                   *(f"{package}={version}" for package, version in targets))
        return self.simulate(command, tuple(targets)) if targets else Plan(command, (), ())

    def apply(self, plan):
        if not plan.changes:
            return
        confirmed = self.simulate(plan.command, plan.targets)
        if confirmed != plan:
            raise ManagerError("The APT plan changed after the preview. Run the operation again.")
        self.checked(self.elevated((plan.command[0], "--assume-yes", *plan.command[1:])), stream=True)


def binary_info(tool, env):
    path = shutil.which(tool.executable, path=env["PATH"])
    if not path:
        return None, None, "Executable is missing from the launch PATH."
    packaged_path = Path("/usr/bin", tool.executable)
    resolved = Path(path).resolve()
    shadowed = resolved != packaged_path.resolve() or not resolved.is_relative_to("/usr")
    note = f"PATH resolves outside {packaged_path}." if shadowed else None
    try:
        probe_env = dict(env, LC_ALL="C")
        result = subprocess.run((path, *tool.version_args), env=probe_env,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, errors="replace", timeout=8, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        return path, None, f"Version probe failed: {error}"
    match = re.search(tool.version_pattern, result.stdout, re.MULTILINE | re.IGNORECASE)
    if result.returncode or not match:
        return path, None, f"Version probe returned {result.returncode} without a usable version."
    return path, match[1], note
