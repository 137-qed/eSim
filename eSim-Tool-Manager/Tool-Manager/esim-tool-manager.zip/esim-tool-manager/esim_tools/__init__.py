"""Manage eSim's external tools on Ubuntu."""
