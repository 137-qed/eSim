from dataclasses import dataclass


@dataclass(frozen=True)
class Tool:
    name: str
    package: str
    executable: str
    version_args: tuple[str, ...]
    version_pattern: str
    purpose: str


TOOLS = {
    tool.name: tool
    for tool in (
        Tool("ngspice", "ngspice", "ngspice", ("--version",),
             r"\bngspice[-\s]+([0-9][\w.+-]*)", "SPICE simulation"),
        Tool("kicad", "kicad", "kicad-cli", ("version",),
             r"^([0-9][\w.+-]*)\s*$", "Schematic capture and PCB design"),
        Tool("ghdl", "ghdl-llvm", "ghdl", ("--version",),
             r"^GHDL\s+([0-9][\w.+-]*)", "Standalone VHDL simulation"),
        Tool("verilator", "verilator", "verilator", ("--version",),
             r"^Verilator\s+([0-9][\w.+-]*)", "Standalone Verilog simulation"),
    )
}
CORE = ("ngspice", "kicad")
