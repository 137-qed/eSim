"""Command-line interface and tool management workflows."""

import argparse
from dataclasses import asdict
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from .apt import Apt, ManagerError, VERSION, binary_info, require_ubuntu
from .catalog import CORE, TOOLS
from .workspace import Journal, Settings, default_path


def tool_name(value):
    if value not in TOOLS:
        raise argparse.ArgumentTypeError(f"unknown tool {value!r}. Choose from {', '.join(TOOLS)}.")
    return value


def add_selection(parser):
    parser.add_argument("tools", type=tool_name, nargs="*", metavar="TOOL")


def build_parser():
    parser = argparse.ArgumentParser(
        prog="python3 -m esim_tools",
        description="Install and manage eSim's external tools on Ubuntu.",
        epilog=f"Managed tools: {', '.join(TOOLS)}. Core tools: {', '.join(CORE)}.",
    )
    parser.add_argument("--profile", type=Path, help="use a different JSON launch profile")
    sub = parser.add_subparsers(dest="command", required=True)

    for name, help_text in (
        ("status", "list package and executable versions"),
        ("updates", "list upgrade candidates from the current APT index"),
        ("doctor", "diagnose required tools, APT dependencies, and PATH"),
    ):
        command = sub.add_parser(name, help=help_text)
        add_selection(command)
        command.add_argument("--json", action="store_true", help="emit structured output")
        if name == "doctor":
            command.add_argument("--esim", action="store_true", help="also check the eSim launcher")
            command.add_argument("--minimum", action="append", default=[], metavar="TOOL=VERSION",
                                 help="require an installed version at or above the given floor")

    for name, help_text in (
        ("plan", "preview a package transaction"),
        ("install", "install selected tools and their dependencies"),
        ("upgrade", "upgrade selected installed tools"),
    ):
        command = sub.add_parser(name, help=help_text)
        if name == "plan":
            command.add_argument("operation", choices=("install", "upgrade"))
            command.add_argument("--json", action="store_true", help="emit a structured plan")
        else:
            command.add_argument("-y", "--yes", action="store_true", help="approve the preview")
        add_selection(command)
        command.add_argument("--version", action="append", default=[], metavar="TOOL=VERSION",
                             help="use an exact, available Debian package version")

    sub.add_parser("refresh", help="refresh APT package indexes from configured repositories")
    config = sub.add_parser("config", help="show or edit the eSim launch profile")
    config_commands = config.add_subparsers(dest="operation", required=True)
    config_commands.add_parser("show", help="display the current launcher and tool directories")
    edit = config_commands.add_parser("set", help="set launch settings")
    edit.add_argument("--launcher", help="absolute eSim executable path, or esim for PATH lookup")
    dirs = edit.add_mutually_exclusive_group()
    dirs.add_argument("--bin-dir", action="append", metavar="ABSOLUTE_PATH",
                      help="replace the tool directory list, in the given order")
    dirs.add_argument("--clear-bin-dirs", action="store_true",
                      help="restore the inherited PATH")

    launch = sub.add_parser("run", help="launch eSim with the tool directories on PATH")
    launch.add_argument("args", nargs=argparse.REMAINDER, help="eSim arguments after --")
    logs = sub.add_parser("logs", help="show recent action journal entries")
    logs.add_argument("-n", "--lines", type=int, default=20, help="number of entries to display")
    return parser


def select(apt, args, operation):
    if args.tools:
        return tuple(dict.fromkeys(args.tools))
    if operation == "upgrade":
        return tuple(name for name, tool in TOOLS.items() if apt.inspect(tool).state != "absent")
    if operation == "updates":
        return tuple(name for name, tool in TOOLS.items() if apt.inspect(tool).installed)
    return CORE if operation in {"install", "doctor"} else tuple(TOOLS)


def parse_pins(values, selected):
    pins = {}
    for value in values:
        name, separator, version = value.partition("=")
        if not separator or name not in selected or not VERSION.fullmatch(version):
            raise ManagerError(f"Invalid version pin {value!r}. Use selected-tool=Debian-version.")
        if name in pins:
            raise ManagerError(f"Specify at most one version for {name}.")
        pins[name] = version
    return pins


def inspect_tools(apt, selected, settings):
    rows = []
    env = settings.environment()
    for name in selected:
        tool = TOOLS[name]
        package = apt.inspect(tool)
        path, version, note = binary_info(tool, env)
        upgrade = bool(package.installed and package.candidate and
                       apt.newer(package.candidate, package.installed))
        rows.append(dict(
            tool=name, package=tool.package, purpose=tool.purpose,
            **asdict(package), update_available=upgrade, executable=path,
            executable_version=version, note=note,
        ))
    return rows


def show_rows(rows):
    if not rows:
        print("No matching tools.")
        return
    print(f"{'Tool':<12} {'Installed package':<25} {'APT candidate':<25} Status")
    for row in rows:
        state = row["state"]
        if row["update_available"]:
            state = "update available"
        if row["held"]:
            state += " (held)"
        print(f"{row['tool']:<12} {(row['installed'] or '-'):25} {(row['candidate'] or '-'):25} {state}")
        if row["executable"]:
            print(f"  {row['executable']} · {row['executable_version'] or 'version unknown'}")
        if row["note"]:
            print(f"  {row['note']}")


def diagnostics(apt, rows, settings, check_esim, minimums):
    issues = []
    for row in rows:
        name = row["tool"]
        if row["state"] == "absent":
            remedy = f"Run install {name}."
            if not row["candidate"]:
                remedy = "No APT candidate. Check Ubuntu package sources and run refresh."
            issues.append(f"{name}: {remedy}")
        elif row["state"] != "installed":
            issues.append(f"{name}: package is {row['state']}. Run dpkg --audit.")
        elif row["note"]:
            issues.append(f"{name}: {row['note']}")
        minimum = minimums.get(name)
        if minimum and row["installed"] and apt.newer(minimum, row["installed"]):
            issues.append(f"{name}: installed {row['installed']}, requires at least {minimum}.")
    try:
        apt.checked(("/usr/bin/apt-get", "--simulate", "check"))
    except ManagerError as error:
        issues.append(f"APT dependency check failed. {error}")
    if check_esim and not shutil.which(settings.launcher, path=settings.environment()["PATH"]):
        issues.append("eSim launcher missing. Install eSim or configure its absolute launcher path.")
    return issues


def show_status(apt, args, settings):
    selected = select(apt, args, args.command)
    rows = inspect_tools(apt, selected, settings)
    if args.command == "updates":
        rows = [row for row in rows if row["update_available"]]
    issues = []
    if args.command == "doctor":
        minimums = parse_pins(args.minimum, selected)
        issues = diagnostics(apt, rows, settings, args.esim, minimums)
    if args.json:
        payload = {"tools": rows, "issues": issues} if args.command == "doctor" else rows
        print(json.dumps(payload, indent=2))
    else:
        if args.command == "updates" and not rows:
            print("No updates for the selected installed tools in the current APT index.")
        else:
            show_rows(rows)
        if args.command == "doctor":
            if issues:
                for issue in issues:
                    print(f"  • {issue}")
            else:
                print("Selected tools and the APT dependency check passed.")
    return 1 if issues else 0


def show_plan(plan, as_json=False):
    if as_json:
        print(json.dumps({"targets": dict(plan.targets), "changes": [asdict(c) for c in plan.changes]},
                         indent=2))
    elif not plan.changes:
        print("No package changes needed.")
    else:
        print(f"APT plan · {len(plan.changes)} package change(s)")
        targets = dict(plan.targets)
        for item in plan.changes:
            role = "requested" if item.package.split(":", 1)[0] in targets else "dependency"
            print(f"  {item.package:<28} {item.before or '(new)'} → {item.after}  [{role}]")


def package_operation(apt, args, journal):
    operation = args.operation if args.command == "plan" else args.command
    selected = select(apt, args, operation)
    pins = parse_pins(args.version, selected)
    if args.command == "plan":
        show_plan(apt.plan(operation, [TOOLS[name] for name in selected], pins), args.json)
        return 0

    with journal.mutation_lock():
        plan = apt.plan(operation, [TOOLS[name] for name in selected], pins)
        show_plan(plan)
        if plan.changes and not args.yes:
            if not sys.stdin.isatty():
                raise ManagerError("Re-run with --yes to approve package changes in a non-interactive shell.")
            if input("Apply this APT transaction? [y/N] ").strip().lower() not in {"y", "yes"}:
                journal.append(operation, "cancelled", tools=selected, targets=dict(plan.targets))
                return 0
        journal.append(operation, "started", tools=selected, targets=dict(plan.targets))
        sys.stdout.flush()
        apt.apply(plan)
        actual = {TOOLS[name].package: apt.inspect(TOOLS[name]).installed for name in selected}
        for package, version in plan.targets:
            if actual[package] != version:
                raise ManagerError(f"Verification failed for {package}: expected {version}, got {actual[package]}.")
        journal.append(operation, "applied" if plan.changes else "no-change",
                       installed=actual, changes=len(plan.changes))
        if plan.changes:
            print("Requested package versions verified.")
    return 0


def config_operation(args, profile, journal):
    if args.operation == "show":
        settings = Settings.read(profile)
    else:
        if args.launcher is None and args.bin_dir is None and not args.clear_bin_dirs:
            raise ManagerError("Supply --launcher, --bin-dir, or --clear-bin-dirs.")
        with journal.mutation_lock():
            current = Settings.read(profile)
            launcher = current.launcher if args.launcher is None else args.launcher
            paths = () if args.clear_bin_dirs else current.bin_dirs
            if args.bin_dir is not None:
                paths = args.bin_dir
            settings = Settings.validate(launcher, paths)
            if settings.launcher != "esim" and not shutil.which(settings.launcher):
                raise ManagerError(f"Launcher is missing or not executable: {settings.launcher}")
            for path in settings.bin_dirs:
                if not Path(path).is_dir():
                    raise ManagerError(f"Tool directory does not exist: {path}")
            settings.write(profile)
            journal.append("config", "saved", directories=len(settings.bin_dirs))
    print(json.dumps({"profile": str(profile), **asdict(settings)}, indent=2))
    return 0


def dispatch(args, journal, profile):
    apt = Apt()
    if args.command == "logs":
        if args.lines < 1:
            raise ManagerError("The number of log lines must be positive.")
        entries = journal.tail(args.lines)
        if not entries:
            print(f"No entries in {journal.path}.")
        else:
            for entry in entries:
                print(json.dumps(entry, sort_keys=True))
        return 0
    if args.command == "refresh":
        with journal.mutation_lock():
            journal.append("refresh", "started")
            apt.refresh()
            journal.append("refresh", "complete")
        return 0
    if args.command in {"plan", "install", "upgrade"}:
        return package_operation(apt, args, journal)

    if args.command == "config":
        return config_operation(args, profile, journal)
    settings = Settings.read(profile)
    if args.command in {"status", "updates", "doctor"}:
        return show_status(apt, args, settings)

    env = settings.environment()
    launcher = shutil.which(settings.launcher, path=env["PATH"])
    if not launcher:
        raise ManagerError("eSim launcher missing. Install eSim or configure its absolute launcher path.")
    positional = args.args[1:] if args.args[:1] == ["--"] else args.args
    journal.append("run", "started")
    result = subprocess.run((launcher, *positional), env=env, check=False)
    journal.append("run", "finished" if result.returncode == 0 else "error", exit_code=result.returncode)
    return result.returncode if result.returncode >= 0 else 128 - result.returncode


def main(argv=None):
    args = build_parser().parse_args(argv)
    profile = args.profile or default_path("XDG_CONFIG_HOME", ".config", "config.json")
    journal = Journal(default_path("XDG_STATE_HOME", ".local/state", "actions.jsonl"))
    try:
        require_ubuntu()
        return dispatch(args, journal, profile)
    except (ManagerError, OSError, ValueError, KeyboardInterrupt, EOFError) as error:
        interrupted = isinstance(error, (KeyboardInterrupt, EOFError))
        reason = str(error) or "Operation cancelled or input closed."
        print(f"eSim Tool Manager: {reason}", file=sys.stderr)
        try:
            journal.append(args.command, "cancelled" if interrupted else "error",
                           reason=reason.splitlines()[0])
        except OSError as log_error:
            print(f"Could not write the action journal: {log_error}", file=sys.stderr)
        return 130 if interrupted else 2
