#!/usr/bin/env bash
# Opt-in integration test. All APT changes stay inside a disposable container.
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
image=${ESIM_TEST_IMAGE:-ubuntu@sha256:9c7f200c07e3d4a03e7249d2c16bf66a51120fb876aa2242cf31451412543289}
docker run --rm --platform linux/amd64 --cpus=2 --memory=1200m -i \
    --mount "type=bind,source=$root,target=/work,readonly" \
    --workdir /work -e PYTHONDONTWRITEBYTECODE=1 "$image" bash -s <<'CONTAINER'
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
. /etc/os-release
[[ $ID == ubuntu && $VERSION_CODENAME == noble ]]
printf 'Test environment: %s (%s)\n' "$PRETTY_NAME" "$(dpkg --print-architecture)"

apt-get -qq update
apt-get -y -qq --no-install-recommends install python3 sudo > /tmp/bootstrap.log 2>&1 ||
    { cat /tmp/bootstrap.log; exit 1; }
useradd --create-home --shell /bin/bash tester
printf 'tester ALL=(root) NOPASSWD: /usr/bin/apt-get\n' >/etc/sudoers.d/esim-test
chmod 0440 /etc/sudoers.d/esim-test

manager() {
    runuser -u tester -- env PYTHONDONTWRITEBYTECODE=1 python3 -m esim_tools "$@"
}

manager refresh

if manager doctor ngspice --json > /tmp/esim-doctor.json; then
    printf 'Expected doctor to detect a missing tool.\n' >&2
    exit 1
else
    test "$?" -eq 1
fi
python3 -c 'import json; d=json.load(open("/tmp/esim-doctor.json")); assert d["tools"][0]["state"] == "absent"; assert d["issues"]'
manager plan install kicad --json | python3 -c 'import json,sys; plan=json.load(sys.stdin); assert "kicad" in plan["targets"]; print("PASS KiCad plan lists", len(plan["changes"]), "APT changes")'
if dpkg-query -W kicad >/dev/null 2>&1; then
    printf 'KiCad preview changed the package database.\n' >&2
    exit 1
fi

old_ghdl=4.1.0+dfsg-0ubuntu2
# GHDL and ghdl-common are an exact-version pair. Pin the companion only
# inside the container so APT can install the older release first.
preferences=/etc/apt/preferences.d/esim-ghdl-baseline
printf 'Package: ghdl-common\nPin: version %s\nPin-Priority: 1000\n' "$old_ghdl" > "$preferences"
manager install ngspice ghdl --version "ghdl=$old_ghdl" --yes > /tmp/esim-install.log 2>&1 ||
    { cat /tmp/esim-install.log; exit 1; }
tail -n 5 /tmp/esim-install.log
manager status ngspice ghdl --json | python3 -c '
import json, sys
rows = {r["tool"]: r for r in json.load(sys.stdin)}
assert rows["ghdl"]["installed"] == "4.1.0+dfsg-0ubuntu2"
assert all(r["state"] == "installed" and r["executable_version"] for r in rows.values()), rows
for r in rows.values():
    print("PASS installed {tool} {installed} (binary {executable_version})".format(**r))
'

rm -- "$preferences"
manager refresh
manager updates ghdl --json | python3 -c '
import json, sys
rows = json.load(sys.stdin)
assert len(rows) == 1 and rows[0]["update_available"], rows
print("PASS GHDL update available:", rows[0]["installed"], "->", rows[0]["candidate"])
'
manager upgrade ghdl --yes > /tmp/esim-upgrade.log 2>&1 ||
    { cat /tmp/esim-upgrade.log; exit 1; }
tail -n 5 /tmp/esim-upgrade.log
manager doctor ngspice ghdl --minimum ghdl=4.1.0+dfsg-0ubuntu2.1 --json | python3 -c '
import json, sys
report = json.load(sys.stdin)
assert not report["issues"], report
assert all(not row["update_available"] for row in report["tools"]), report
print("PASS doctor and upgrade postcondition")
'
manager upgrade ghdl --yes | grep -F 'No package changes needed.'

install -d -o tester -g tester /home/tester/demo-bin
cat >/home/tester/demo-bin/esim <<'DEMO'
#!/bin/sh
test "${PATH%%:*}" = /home/tester/demo-bin
test "$1" = "argument with spaces"
ngspice --version >/dev/null
printf 'PASS launcher profile and exact argument forwarding\n'
DEMO
chmod 0755 /home/tester/demo-bin/esim
manager config set --bin-dir /home/tester/demo-bin
manager doctor ngspice --esim
manager run -- 'argument with spaces'
manager logs -n 20 | python3 -c '
import json, sys
events = [json.loads(line) for line in sys.stdin]
assert any(e["action"] == "install" and e["result"] == "applied" for e in events)
assert any(e["action"] == "upgrade" and e["result"] == "applied" for e in events)
assert any(e["action"] == "run" and e["result"] == "finished" for e in events)
print("PASS action journal")
'

cat >/tmp/esim-divider.cir <<'CIRCUIT'
10 V resistor divider
V1 in 0 10
R1 in out 1k
R2 out 0 1k
.control
op
print v(out)
quit
.endc
.end
CIRCUIT
ngspice -b /tmp/esim-divider.cir | grep -E 'v\(out\)\s*=\s*5\.0+e[+]00'
printf 'PASS ngspice calculated a 5 V operating point\n'
CONTAINER
