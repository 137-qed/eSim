"""Targeted checks of the package-plan, version, and configuration contracts."""

import os
from pathlib import Path
from subprocess import CompletedProcess
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import Mock, patch

from esim_tools.apt import Apt, Change, ManagerError, Package, Plan
from esim_tools.catalog import TOOLS
from esim_tools.cli import build_parser, diagnostics, parse_pins
from esim_tools.workspace import Journal, Settings


def completed(stdout="", stderr="", status=0):
    return CompletedProcess([], status, stdout, stderr)


class AptTests(unittest.TestCase):
    def setUp(self):
        self.run = Mock()
        self.apt = Apt(run=self.run, effective_uid=lambda: 0)
        self.tool = TOOLS["ngspice"]

    def test_dpkg_hold_and_apt_candidate_are_distinct(self):
        self.run.side_effect = [
            completed("hold\tinstalled\t1:42-1\n"),
            completed("ngspice:\n  Installed: 1:42-1\n  Candidate: 1:42-2\n"),
        ]
        self.assertEqual(self.apt.inspect(self.tool), Package("installed", "1:42-1", "1:42-2", True))

    def test_missing_package_can_have_candidate(self):
        self.run.side_effect = [
            completed(stderr="dpkg-query: no packages found matching ngspice", status=1),
            completed("ngspice:\n  Installed: (none)\n  Candidate: 42+ds-3build1\n"),
        ]
        self.assertEqual(self.apt.inspect(self.tool), Package("absent", None, "42+ds-3build1"))

    def test_plan_pins_target_and_exposes_transitive_changes(self):
        self.apt.inspect = Mock(return_value=Package("absent", None, "42-2"))
        self.run.return_value = completed(
            "Inst libspice (1.2 Ubuntu [amd64])\nInst ngspice (42-1 Ubuntu [amd64])\n"
            "Conf libspice (1.2 Ubuntu [amd64])\nConf ngspice (42-1 Ubuntu [amd64])"
        )
        plan = self.apt.plan("install", [self.tool], {"ngspice": "42-1"})
        self.assertEqual(plan.targets, (("ngspice", "42-1"),))
        self.assertEqual(plan.command[-2:], ("install", "ngspice=42-1"))
        self.assertIn("--no-remove", plan.command)
        self.assertEqual(plan.changes, (Change("libspice", None, "1.2"), Change("ngspice", None, "42-1")))
        self.assertIn("--simulate", self.run.call_args.args[0])

    def test_plan_rejects_removal_downgrade_and_pending_configuration(self):
        for output, message in (
            ("Remv important-package [1]", "remove or downgrade"),
            ("The following packages will be DOWNGRADED:", "remove or downgrade"),
            ("Conf unfinished (1 Ubuntu [amd64])", "configuration is pending"),
        ):
            with self.subTest(output=output):
                self.run.return_value = completed(output)
                with self.assertRaisesRegex(ManagerError, message):
                    self.apt.simulate(("/usr/bin/apt-get", "install", "ngspice=42"), ())

    def test_simulation_must_schedule_exact_target(self):
        self.run.return_value = completed("Inst ngspice (42-2 Ubuntu [amd64])")
        with self.assertRaisesRegex(ManagerError, "requested version"):
            self.apt.simulate(("/usr/bin/apt-get", "install", "ngspice=42-1"), (("ngspice", "42-1"),))

    def test_changed_transaction_is_never_applied(self):
        command = ("/usr/bin/apt-get", "install", "ngspice=42-2")
        plan = Plan(command, (("ngspice", "42-2"),), (Change("ngspice", "42-1", "42-2"),))
        self.run.return_value = completed(
            "Inst libspice (1.1 Ubuntu [amd64])\nInst ngspice [42-1] (42-2 Ubuntu [amd64])"
        )
        with self.assertRaisesRegex(ManagerError, "plan changed"):
            self.apt.apply(plan)
        self.assertEqual(self.run.call_count, 1)
        self.assertIn("--simulate", self.run.call_args.args[0])

    def test_applying_matching_plan_runs_one_exact_apt_command(self):
        command = ("/usr/bin/apt-get", "--no-remove", "install", "ngspice=42-2")
        plan = Plan(command, (("ngspice", "42-2"),), (Change("ngspice", "42-1", "42-2"),))
        self.run.side_effect = [completed("Inst ngspice [42-1] (42-2 Ubuntu [amd64])"), completed()]
        self.apt.apply(plan)
        self.assertEqual(self.run.call_count, 2)
        self.assertEqual(self.run.call_args.args[0][1:], ("--assume-yes", "--no-remove",
                                                         "install", "ngspice=42-2"))
        self.assertTrue(self.run.call_args.kwargs["stream"])

    def test_upgrade_requires_an_installed_package(self):
        self.apt.inspect = Mock(return_value=Package("absent", None, "42"))
        with self.assertRaisesRegex(ManagerError, "Run install first"):
            self.apt.plan("upgrade", [self.tool], {})
        self.run.assert_not_called()

    def test_held_package_blocks_upgrade(self):
        self.apt.inspect = Mock(return_value=Package("installed", "41", "42", True))
        self.apt.newer = Mock(return_value=False)
        with self.assertRaisesRegex(ManagerError, "held by APT"):
            self.apt.plan("upgrade", [self.tool], {})
        self.run.assert_not_called()

    def test_version_comparison_follows_debian_epoch_and_prerelease_order(self):
        apt = Apt()
        self.assertTrue(apt.newer("1:2.0", "9.9"))
        self.assertTrue(apt.newer("42.0", "42.0~rc1"))
        self.assertFalse(apt.newer("42.0-1", "42.0-1"))


class InterfaceTests(unittest.TestCase):
    def test_parser_accepts_default_and_explicit_selection(self):
        parser = build_parser()
        self.assertEqual(parser.parse_args(["install"]).tools, [])
        args = parser.parse_args(["plan", "upgrade", "ghdl", "--json"])
        self.assertEqual((args.operation, args.tools, args.json), ("upgrade", ["ghdl"], True))

    def test_version_input_rejects_unknown_names_bad_formats_and_duplicates(self):
        valid = {"ngspice": "1:42~rc1-1+build2"}
        self.assertEqual(parse_pins(["ngspice=1:42~rc1-1+build2"], ["ngspice"]), valid)
        for values in (["elsewhere=42"], ["ngspice=--purge"], ["ngspice=42", "ngspice=41"]):
            with self.subTest(values=values), self.assertRaises(ManagerError):
                parse_pins(values, ["ngspice"])

    def test_doctor_uses_debian_package_floor(self):
        apt = Mock()
        apt.newer.return_value = True
        rows = [{"tool": "kicad", "state": "installed", "installed": "7.0.11", "note": None}]
        findings = diagnostics(apt, rows, Settings(), False, {"kicad": "8.0"})
        self.assertEqual(findings, ["kicad: installed 7.0.11, requires at least 8.0."])
        apt.newer.assert_called_once_with("8.0", "7.0.11")

    def test_profile_round_trip_preserves_paths_with_spaces_and_scope(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "config.json"
            settings = Settings.validate("/opt/eSim release/esim", ("/opt/my tools", "/opt/my tools"))
            settings.write(path)
            self.assertEqual(Settings.read(path), settings)
            with patch.dict(os.environ, {"PATH": "/usr/bin"}):
                self.assertEqual(settings.environment()["PATH"], "/opt/my tools:/usr/bin")
                self.assertEqual(os.environ["PATH"], "/usr/bin")

    def test_journal_and_mutation_lock(self):
        with TemporaryDirectory() as directory:
            journal = Journal(Path(directory) / "actions.jsonl")
            journal.append("install", "applied", installed={"ngspice": "42"})
            journal.append("upgrade", "no-change")
            self.assertEqual(journal.tail(1)[0]["result"], "no-change")
            with journal.mutation_lock():
                with self.assertRaisesRegex(ManagerError, "Another"):
                    with journal.mutation_lock():
                        self.fail("Concurrent writer acquired the same lock.")
            with journal.mutation_lock():
                pass


if __name__ == "__main__":
    unittest.main()
